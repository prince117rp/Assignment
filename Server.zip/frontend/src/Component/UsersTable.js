import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useTable } from 'react-table';

const UsersTable = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const result = await axios.get('http://localhost:5000/users');
      const filteredData = result.data.filter(user => user.income < 5 && (user.car === 'BMW' || user.car=== 'Mercedes'));
      setUsers(filteredData);
    };
    fetchData();
  }, []);


  const data = React.useMemo(() => users, [users]);

  const columns = React.useMemo(
    () => [
      {
        Header: 'Name',
        accessor: 'name',
      },
      {
        Header: 'Age',
        accessor: 'age',
      },
      {
        Header: 'Income',
        accessor: 'income',
      },
      {
        Header: 'Car Brand',
        accessor: 'car.brand',
      },
      {
        Header: 'Car Model',
        accessor: 'car.model',
      },
      {
        Header: 'Location',
        accessor: 'location',
      },
    ],
    []
  );

  const tableInstance = useTable({ columns, data });

  const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } = tableInstance;

  return (
    <table {...getTableProps()} className="table">
      <thead>
        {headerGroups.map(headerGroup => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map(column => (
              <th {...column.getHeaderProps()}>{column.render('Header')}</th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map(row => {
          prepareRow(row);
          return (
            <tr {...row.getRowProps()}>
              {row.cells.map(cell => {
                return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>;
              })}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default UsersTable;
