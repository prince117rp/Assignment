const express = require('express');
const fs = require('fs');

const app = express();

// get users with income < 5 and car brand BMW or Mercedes
app.get('/users', (req, res) => {
  fs.readFile('./users.json', 'utf8', (err, data) => {
    if (err) {
      res.status(500).send(err);
    } else {
      const users = JSON.parse(data).filter(user => user.income < 5 && (user.car === 'BMW' || user.car === 'Mercedes'));
      res.send(users);
    }
  });
});

// start the server
app.listen(5000, () => {
  console.log('Server started on port 5000');
});
